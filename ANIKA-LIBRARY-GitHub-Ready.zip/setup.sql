-- ANIKA LIBRARY: Supabase Storage setup
-- Run this once in Supabase Dashboard > SQL Editor.
-- The students table already exists in your project.

insert into storage.buckets (id, name, public)
values ('student-photos', 'student-photos', true)
on conflict (id) do update set public = true;

drop policy if exists "Public read student photos" on storage.objects;
create policy "Public read student photos"
on storage.objects for select
to public
using (bucket_id = 'student-photos');

drop policy if exists "Anon upload student photos" on storage.objects;
create policy "Anon upload student photos"
on storage.objects for insert
to anon
with check (bucket_id = 'student-photos');

drop policy if exists "Anon update student photos" on storage.objects;
create policy "Anon update student photos"
on storage.objects for update
to anon
using (bucket_id = 'student-photos')
with check (bucket_id = 'student-photos');

drop policy if exists "Anon delete student photos" on storage.objects;
create policy "Anon delete student photos"
on storage.objects for delete
to anon
using (bucket_id = 'student-photos');
